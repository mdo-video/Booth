package it.mdo.booth.control

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Parla con la dashcam del tablet: la trova via mDNS (o IP a mano) e legge stato, log e video. */
@Suppress("DEPRECATION")
class Api(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("control", Context.MODE_PRIVATE)
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val http = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    var key by mutableStateOf(prefs.getString("key", "") ?: "")
    var manualHost by mutableStateOf(prefs.getString("host", "") ?: "")
    var foundHost by mutableStateOf<String?>(null)
    var status by mutableStateOf<JSONObject?>(null)
    var lastOk by mutableLongStateOf(0L)
    var authError by mutableStateOf(false)
    var log by mutableStateOf<List<JSONObject>>(emptyList())
    var clips by mutableStateOf<List<JSONObject>>(emptyList())

    fun saveConn() {
        prefs.edit().putString("key", key).putString("host", manualHost).apply()
    }

    val base: String?
        get() {
            val h = manualHost.trim().ifEmpty { foundHost } ?: return null
            return "http://" + (if (h.contains(':')) h else "$h:8090")
        }

    private var resolving = false
    private val discovery = object : NsdManager.DiscoveryListener {
        override fun onServiceFound(info: NsdServiceInfo) {
            if (!info.serviceType.contains("_boothdash") || resolving) return
            resolving = true
            nsd.resolveService(info, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, errorCode: Int) { resolving = false }
                override fun onServiceResolved(i: NsdServiceInfo) {
                    resolving = false
                    foundHost = "${i.host.hostAddress}:${i.port}"
                }
            })
        }
        override fun onServiceLost(info: NsdServiceInfo) {}
        override fun onDiscoveryStarted(serviceType: String) {}
        override fun onDiscoveryStopped(serviceType: String) {}
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
    }

    fun start() {
        runCatching { nsd.discoverServices("_boothdash._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery) }
    }

    fun stop() {
        runCatching { nsd.stopServiceDiscovery(discovery) }
    }

    fun clipUrl(name: String): String = "$base/clip/$name?k=$key"

    private fun get(url: String): Pair<Int, String> =
        http.newCall(Request.Builder().url(url).build()).execute().use { it.code to (it.body?.string() ?: "") }

    suspend fun post(path: String, body: String = "") = withContext(Dispatchers.IO) {
        val b = base ?: return@withContext
        runCatching {
            http.newCall(
                Request.Builder().url("$b$path?k=$key")
                    .post(body.toRequestBody("application/json".toMediaType())).build()
            ).execute().close()
        }
    }

    suspend fun refresh() = withContext(Dispatchers.IO) {
        val b = base ?: return@withContext
        try {
            val st = get("$b/status?k=$key")
            if (st.first == 401) {
                authError = true
                return@withContext
            }
            if (st.first != 200) return@withContext
            authError = false
            status = JSONObject(st.second)
            lastOk = System.currentTimeMillis()
            val lg = JSONArray(get("$b/log?n=400&k=$key").second)
            log = List(lg.length()) { lg.getJSONObject(it) }.reversed()
            val cl = JSONArray(get("$b/clips?k=$key").second)
            clips = List(cl.length()) { cl.getJSONObject(it) }
        } catch (_: Exception) {
        }
    }
}
