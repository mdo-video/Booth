package it.mdo.booth.control

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var api: Api

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        api = Api(this).also { it.start() }
        val upd = UpdateManager(this, "booth-control.apk", BuildConfig.UPDATE_TOKEN).also { it.check() }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                ControlApp(api, upd)
            }
        }
    }

    override fun onDestroy() {
        api.stop()
        super.onDestroy()
    }
}

private val BG = Color(0xFF101216)
private val CARD = Color(0xFF1B1E25)
private val GREEN = Color(0xFF2E7D32)
private val AMBER = Color(0xFFB26A00)
private val RED = Color(0xFFB71C1C)

private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.ITALY)
private val dateFmt = SimpleDateFormat("dd/MM HH:mm", Locale.ITALY)

private fun ago(ms: Long): String {
    val s = ms / 1000
    return when {
        s < 60 -> "${s}s fa"
        s < 3600 -> "${s / 60} min fa"
        else -> "${s / 3600} h ${(s % 3600) / 60} min fa"
    }
}

private fun eventText(e: String): String = when (e) {
    "REC_START" -> "🎬 Registrazione dedica avviata"
    "FOTO" -> "📸 Foto scattata"
    "DEDICA_PRONTA" -> "👀 Anteprima pronta"
    "DEDICA_SALVATA" -> "✅ Dedica salvata"
    "DEDICA_SCARTATA" -> "🔁 Dedica scartata"
    "DEDICA_ELIMINATA" -> "🗑 Dedica eliminata"
    "CONDIVISA" -> "📤 Dedica condivisa"
    "CONDIVISIONE_FALLITA" -> "⚠ Condivisione fallita"
    "QR" -> "🔳 QR mostrato"
    "PHONE_ON" -> "📱 Telefono camera collegato"
    "PHONE_OFF" -> "⚠ Telefono camera scollegato"
    "BATT_BASSA" -> "🔋 Batteria del tablet bassa"
    "SPAZIO_BASSO" -> "💾 Spazio del tablet quasi finito"
    "DASH_AVVIO" -> "🟢 Dashcam avviata"
    "DASH_STOP" -> "⏹ Dashcam fermata"
    "DASH_ERRORE" -> "⚠ Errore dashcam"
    "DASH_CONFIG" -> "⚙ Impostazioni dashcam cambiate"
    "APP_AVVIATA" -> "🔄 App del tablet avviata"
    else -> e
}

private class Health(val level: Int, val title: String, val reasons: List<String>)

private fun health(api: Api): Health {
    val st: JSONObject? = api.status
    if (api.base == null) return Health(2, "Tablet non trovato", listOf("Sei sulla stessa rete Wi-Fi del tablet? Oppure scrivi l'IP in Impostazioni."))
    if (api.authError) return Health(2, "Codice errato", listOf("Scrivi in Impostazioni il codice mostrato sul tablet."))
    val age = System.currentTimeMillis() - api.lastOk
    if (st == null || age > 15_000) {
        return Health(2, "Tablet non raggiungibile", listOf(if (st == null) "Nessuna risposta finora" else "Ultima risposta ${ago(age)}"))
    }
    val bad = mutableListOf<String>()
    val warn = mutableListOf<String>()
    val d = st.getJSONObject("dash")
    val bat = st.getJSONObject("battery")
    val sto = st.getJSONObject("storage")
    val ph = st.getJSONObject("phone")
    val phInfo = ph.optJSONObject("info") ?: JSONObject()
    if (d.optBoolean("enabled") && !d.optBoolean("recording")) bad.add("La dashcam non sta registrando")
    if (d.optString("lastError").isNotEmpty()) warn.add("Dashcam: " + d.optString("lastError"))
    val last = d.optLong("lastSegmentAt")
    val seg = d.optInt("segMin", 5)
    if (d.optBoolean("recording") && last > 0 && System.currentTimeMillis() - last > (seg * 60_000L * 3 / 2 + 60_000L)) {
        bad.add("Nessun nuovo file da " + ago(System.currentTimeMillis() - last).removeSuffix(" fa"))
    }
    if (bat.optInt("pct", -1) in 0..19 && !bat.optBoolean("charging")) warn.add("Batteria del tablet bassa (${bat.optInt("pct")}%)")
    if (sto.optLong("freeMb", 99999) < 3000) warn.add("Spazio del tablet quasi finito")
    if (!ph.optBoolean("connected")) warn.add("Telefono camera non collegato al tablet")
    if (phInfo.optInt("battery", 100) in 0..19 && !phInfo.optBoolean("charging")) warn.add("Batteria del telefono camera bassa")
    if (phInfo.has("freeMb") && phInfo.optLong("freeMb") in 0..1999) warn.add("Spazio del telefono camera quasi finito")
    val all = bad + warn
    return when {
        bad.isNotEmpty() -> Health(2, "ATTENZIONE", all)
        warn.isNotEmpty() -> Health(1, "Da controllare", all)
        else -> Health(0, "Tutto OK", emptyList())
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) Color(0xFF3D5AFE) else Color(0xFF2A2E38))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) { Text(text, color = Color.White, fontSize = 15.sp) }
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CARD).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(title, color = Color(0xFF9AA0AC), fontSize = 13.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun Line(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = Color(0xFFB0B5C0), fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun openUrl(ctx: Context, url: String) {
    runCatching {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/mp4").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

@Composable
fun ControlApp(api: Api, upd: UpdateManager) {
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            api.refresh()
            delay(4000)
        }
    }
    Column(Modifier.fillMaxSize().background(BG).padding(top = 28.dp)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Stato", "Log", "Video", "Impost.").forEachIndexed { i, t -> Chip(t, tab == i) { tab = i } }
        }
        Box(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            when (tab) {
                0 -> StatusTab(api)
                1 -> LogTab(api)
                2 -> ClipsTab(api)
                else -> SettingsTab(api, upd)
            }
        }
    }
}

@Composable
private fun StatusTab(api: Api) {
    val h = health(api)
    val st: JSONObject? = api.status
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(when (h.level) { 0 -> GREEN; 1 -> AMBER; else -> RED }).padding(18.dp)
        ) {
            Text(h.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            h.reasons.forEach { Text("• $it", color = Color.White, fontSize = 16.sp) }
        }
        if (st == null) return@Column
        val d = st.getJSONObject("dash")
        val bat = st.getJSONObject("battery")
        val sto = st.getJSONObject("storage")
        val ph = st.getJSONObject("phone")
        val phInfo = ph.optJSONObject("info") ?: JSONObject()
        val today = st.optJSONObject("today") ?: JSONObject()

        Card("DASHCAM") {
            Line("Stato", if (d.optBoolean("recording")) "registra" else "ferma")
            Line("Fotocamere", d.optString("cams"))
            Line("Due fotocamere insieme", if (d.optBoolean("concurrent")) "supportato" else "non supportato")
            val last = d.optLong("lastSegmentAt")
            if (last > 0) Line("Ultimo file iniziato", ago(System.currentTimeMillis() - last))
            Line("File ogni / conservati", "${d.optInt("segMin")} min / ${d.optInt("keepMin")} min")
        }
        Card("TABLET") {
            Line("Batteria", "${bat.optInt("pct")}%" + if (bat.optBoolean("charging")) " ⚡" else "")
            Line("Spazio libero", "%.1f GB".format(sto.optLong("freeMb") / 1024.0))
            Line("Dashcam occupa", "%.1f GB (${sto.optInt("clips")} file)".format(sto.optLong("dashMb") / 1024.0))
            Line("Versione app", st.optString("version"))
        }
        Card("TELEFONO CAMERA") {
            Line("Collegato al tablet", if (ph.optBoolean("connected")) "sì" else "NO")
            if (phInfo.has("battery")) {
                Line("Batteria", "${phInfo.optInt("battery")}%" + if (phInfo.optBoolean("charging")) " ⚡" else "")
            }
            if (phInfo.has("freeMb")) Line("Spazio libero", "%.1f GB".format(phInfo.optLong("freeMb") / 1024.0))
        }
        Card("OGGI") {
            Line("Dediche salvate", today.optInt("DEDICA_SALVATA").toString())
            Line("Dediche scartate", today.optInt("DEDICA_SCARTATA").toString())
            Line("Registrazioni avviate", today.optInt("REC_START").toString())
            Line("Foto", today.optInt("FOTO").toString())
            Line("Condivisioni", today.optInt("CONDIVISA").toString())
            Line("QR mostrati", today.optInt("QR").toString())
        }
    }
}

@Composable
private fun LogTab(api: Api) {
    val ctx = LocalContext.current
    val log = api.log
    val clips = api.clips
    if (log.isEmpty()) {
        Text("Nessun evento ancora.", color = Color.Gray, fontSize = 16.sp)
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(log) { ev ->
            val t = ev.optLong("t")
            val type = ev.optString("e")
            val detail = ev.optString("d")
            val covering = clips.filter { !it.optBoolean("live") && t >= it.optLong("start") && t <= it.optLong("end") + 5000 }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CARD).padding(12.dp)) {
                Row {
                    Text(dateFmt.format(Date(t)), color = Color(0xFF9AA0AC), fontSize = 13.sp, modifier = Modifier.weight(1f))
                }
                Text(eventText(type), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                if (detail.isNotEmpty()) Text(detail, color = Color(0xFFB0B5C0), fontSize = 13.sp)
                if (covering.isNotEmpty()) {
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        covering.forEach { c ->
                            val off = (t - c.optLong("start")) / 1000
                            Chip("▶ " + (if (c.optString("cam") == "front") "fronte" else "retro") + " @%d:%02d".format(off / 60, off % 60), false) {
                                openUrl(ctx, api.clipUrl(c.optString("name")))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClipsTab(api: Api) {
    val ctx = LocalContext.current
    val clips = api.clips
    if (clips.isEmpty()) {
        Text("Nessun video sul tablet.", color = Color.Gray, fontSize = 16.sp)
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(clips) { c ->
            val live = c.optBoolean("live")
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CARD)
                    .clickable(enabled = !live) { openUrl(ctx, api.clipUrl(c.optString("name"))) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        (if (c.optString("cam") == "front") "Frontale" else "Posteriore") + "  " + dateFmt.format(Date(c.optLong("start"))),
                        color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        if (live) "● in registrazione" else "fino alle " + timeFmt.format(Date(c.optLong("end"))),
                        color = if (live) Color(0xFFFF5252) else Color(0xFFB0B5C0), fontSize = 13.sp,
                    )
                }
                Text("%.0f MB".format(c.optLong("size") / 1_048_576.0), color = Color(0xFFB0B5C0), fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun SettingsTab(api: Api, upd: UpdateManager) {
    val scope = rememberCoroutineScope()
    val st: JSONObject? = api.status
    val d = st?.optJSONObject("dash")
    val tabletUpd = st?.optJSONObject("update")
    val mine by upd.status.collectAsState()
    fun cfg(j: JSONObject) = scope.launch {
        api.post("/config", j.toString())
        api.refresh()
    }
    val field = TextStyle(color = Color.White, fontSize = 18.sp)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card("COLLEGAMENTO AL TABLET") {
            OutlinedTextField(
                value = api.key, onValueChange = { api.key = it.filter { c -> c.isDigit() }.take(6); api.saveConn() },
                singleLine = true, label = { Text("Codice (6 cifre, dal tablet)") },
                modifier = Modifier.fillMaxWidth(), textStyle = field,
            )
            OutlinedTextField(
                value = api.manualHost, onValueChange = { api.manualHost = it.trim(); api.saveConn() },
                singleLine = true, label = { Text("IP del tablet (solo se non lo trova da solo)") },
                modifier = Modifier.fillMaxWidth(), textStyle = field,
            )
            Text(
                "Trovato: " + (api.foundHost ?: "no") + "  •  telefono e tablet devono stare sulla stessa rete.",
                color = Color.Gray, fontSize = 13.sp,
            )
        }
        if (d != null) {
            Card("DASHCAM") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Registra", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Switch(checked = d.optBoolean("enabled"), onCheckedChange = { cfg(JSONObject().put("enabled", it)) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Anche posteriore", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Switch(checked = d.optBoolean("useBack"), onCheckedChange = { cfg(JSONObject().put("useBack", it)) })
                }
                Text("Durata di ogni file", color = Color(0xFF9AA0AC), fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 5, 10, 15).forEach { m -> Chip("$m min", d.optInt("segMin") == m) { cfg(JSONObject().put("segMin", m)) } }
                }
                Text("Conserva gli ultimi", color = Color(0xFF9AA0AC), fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(30, 60, 120, 240, 480).forEach { m ->
                        Chip(if (m < 60) "$m min" else "${m / 60} h", d.optInt("keepMin") == m) { cfg(JSONObject().put("keepMin", m)) }
                    }
                }
            }
        }
        Card("AGGIORNAMENTI") {
            Text("App del tablet", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(tabletUpd?.optString("text").orEmpty().ifEmpty { "—" }, color = Color(0xFFB0B5C0), fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Controlla", false) { scope.launch { api.post("/update/check"); delay(2500); api.refresh() } }
                if (tabletUpd?.optBoolean("canInstall") == true) {
                    Chip("Installa sul tablet", true) { scope.launch { api.post("/update/install") } }
                }
            }
            Text("Sul tablet serve un tocco per confermare l'installazione.", color = Color.Gray, fontSize = 12.sp)
            Text("Questa app", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            Text(mine.text, color = Color(0xFFB0B5C0), fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Controlla", false) { upd.check() }
                if (mine.canInstall) Chip("Installa", true) { upd.installNow() }
            }
        }
    }
}
