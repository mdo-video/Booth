# BoothDediche
Due app in un solo progetto Android Studio / GitHub Actions:
- `camera`  -> telefono: registra un "take" temporaneo, lo serve in streaming al tablet (HTTP /take),
               salva in Movies/Booth/<nome>_001.mp4 solo se il tablet dice SAVE. WebSocket :8080 + mDNS.
- `tablet`  -> tablet: preview in mirror, REC, impostazioni remote (qualita, durata, ottica/zoom, torcia,
               esposizione, nome file), anteprima in basso a destra con Rifai / Salva / Condividi.

Novità 1.6
- Cornice (PNG trasparente) su foto e video: il tablet la mostra sopra l'anteprima e la invia al telefono (POST /frame);
  il telefono la applica alle foto (Canvas, ritaglio 16:9) e ai video (Media3 Transformer, qualche secondo dopo lo stop).
  Inclusa "Gaia +30" (assets/frame_gaia30.png); da Impostazioni > CORNICE si può scegliere un'altra immagine dalla galleria.
- Flash nelle foto: usa il flash/doppio LED del telefono (FLASH_MODE_ON); se l'obiettivo grandangolare non ha il flash,
  accende la torcia ~0,5 s prima dello scatto. Tasti rapidi ⚡ (flash) e 🖼 (cornice) sul tablet.

Protocollo: tablet->telefono START|PHOTO|STOP|SAVE|DISCARD|INFO?|SET:{json}  (+ HTTP POST /frame = PNG cornice)
            telefono->tablet STATE:..(anche PROCESSING:<%>)|EVENT:..|INFO:{json} + frame JPEG

## Test fotocamere (modulo `camtest`)
App a parte "Test Camere": mostra se il tablet dichiara il supporto alle fotocamere concorrenti
(`getConcurrentCameraIds`) e prova ad aprire davvero anteriore + posteriore insieme.
Serve a decidere come progettare la dashcam. Non fa parte del booth.

## Novità 1.7 — dashcam, controllo remoto, log, aggiornamenti OTA

**Dashcam (sul tablet)**: servizio in primo piano che registra video+audio a segmenti (5 min di default) e
cancella i più vecchi (conserva 120 min di default, e lascia sempre almeno 2 GB liberi).
Fotocamera frontale + posteriore insieme se Android dichiara la combinazione (`getConcurrentCameraIds`);
altrimenti solo la frontale. Se la posteriore non si apre insieme alla frontale, ripiega da sola sulla frontale.
Audio solo dalla frontale. File in `Android/data/it.mdo.booth.tablet/files/dashcam/`.

**App "Booth Controllo"** (modulo `control`, sul telefono di Marco): stato di salute (verde/giallo/rosso),
contatori di oggi, log eventi con link al video del momento, elenco video, impostazioni dashcam.
Trova il tablet via mDNS `_boothdash._tcp.` (o IP a mano). Il tablet espone HTTP sulla porta 8090 e
richiede il codice a 6 cifre mostrato in Impostazioni → DASHCAM.

**Log eventi** (`events.jsonl` sul tablet): REC_START, FOTO, DEDICA_PRONTA/SALVATA/SCARTATA/ELIMINATA,
CONDIVISA, QR, PHONE_ON/OFF, BATT_BASSA, SPAZIO_BASSO, DASH_*.

**OTA**: ogni app controlla l'ultima Release del repo (tag `v<versionCode>`) e installa il proprio APK
(`booth-camera.apk`, `booth-tablet.apk`, `booth-control.apk`). Versione unica in `gradle.properties`
(`appVersionCode`, `appVersionName`): per rilasciare, aumenta `appVersionCode` e fai commit.
Il workflow `.github/workflows/release-apk.yml` compila e pubblica la release.
