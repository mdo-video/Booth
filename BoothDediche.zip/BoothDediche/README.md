# BoothDediche
Due app in un solo progetto Android Studio / GitHub Actions:
- `camera`  -> telefono: registra un "take" temporaneo, lo serve in streaming al tablet (HTTP /take),
               salva in Movies/Booth/<nome>_001.mp4 solo se il tablet dice SAVE. WebSocket :8080 + mDNS.
- `tablet`  -> tablet: preview in mirror, REC, impostazioni remote (qualita, durata, ottica/zoom, torcia,
               esposizione, nome file), anteprima in basso a destra con Rifai / Salva / Condividi.

Novità 1.6
- Cornice (PNG trasparente) su foto e video: il tablet la mostra sopra l'anteprima e la invia al telefono (POST /frame);
  il telefono la applica alle foto (Canvas, ritaglio 16:9) e ai video (Media3 Transformer, qualche secondo dopo lo stop).
  Inclusa "Gaia +30" (assets/frame_gaia30.png); da Impostazioni > CORNICE si può scegliere un'altra immagine dalla galleria.
- Flash nelle foto: usa il flash/doppio LED del telefono (FLASH_MODE_ON); se l'obiettivo grandangolare non ha il flash,
  accende la torcia ~0,5 s prima dello scatto. Tasti rapidi ⚡ (flash) e 🖼 (cornice) sul tablet.

Protocollo: tablet->telefono START|PHOTO|STOP|SAVE|DISCARD|INFO?|SET:{json}  (+ HTTP POST /frame = PNG cornice)
            telefono->tablet STATE:..(anche PROCESSING:<%>)|EVENT:..|INFO:{json} + frame JPEG
