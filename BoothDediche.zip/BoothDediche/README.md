# BoothDediche
Due app in un solo progetto Android Studio (apri la cartella, "Sync", poi Run per modulo):
- `camera`  -> telefono: registra MP4 in Movies/Booth (dedica_001.mp4...), server WebSocket :8080, annuncio mDNS
- `tablet`  -> tablet: preview in mirror, tasto REC, countdown 3-2-1, stop automatico a 60 s

Protocollo: tablet->telefono "START"/"STOP"; telefono->tablet "STATE:..." + frame JPEG.
Rete: telefono e tablet sullo stesso router (meglio 5 GHz, anche senza internet).
Mic: ricevitore DJI Mic Mini in USB-C sul TELEFONO.
