package it.mdo.booth.camera

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import io.ktor.server.application.install
import io.ktor.server.cio.CIO
import io.ktor.server.engine.ApplicationEngine
import io.ktor.server.engine.embeddedServer
import io.ktor.server.routing.routing
import io.ktor.server.websocket.WebSockets
import io.ktor.server.websocket.webSocket
import io.ktor.websocket.Frame
import io.ktor.websocket.readText
import java.time.Duration
import java.util.Collections

/**
 * WebSocket /ws
 *  tablet -> telefono : testo "START" | "STOP"
 *  telefono -> tablet : testo "STATE:<READY|RECORDING|SAVED:file|ERROR:x>" + frame JPEG binari
 */
class StreamServer(private val onCommand: (String) -> Unit) {
    companion object {
        const val PORT = 8080
    }

    private val sessions = Collections.synchronizedSet(mutableSetOf<io.ktor.server.websocket.DefaultWebSocketServerSession>())
    @Volatile private var lastState = "READY"
    private var engine: ApplicationEngine? = null

    fun hasClients(): Boolean = sessions.isNotEmpty()

    fun start() {
        engine = embeddedServer(CIO, port = PORT) {
            install(WebSockets) {
                pingPeriod = Duration.ofSeconds(5)
                timeout = Duration.ofSeconds(15)
            }
            routing {
                webSocket("/ws") {
                    sessions.add(this)
                    outgoing.trySend(Frame.Text("STATE:$lastState"))
                    try {
                        for (f in incoming) {
                            if (f is Frame.Text) onCommand(f.readText())
                        }
                    } finally {
                        sessions.remove(this)
                    }
                }
            }
        }.start(wait = false)
    }

    fun sendFrame(jpeg: ByteArray) {
        synchronized(sessions) { sessions.forEach { it.outgoing.trySend(Frame.Binary(true, jpeg)) } }
    }

    fun sendState(state: String) {
        lastState = state
        synchronized(sessions) { sessions.forEach { it.outgoing.trySend(Frame.Text("STATE:$state")) } }
    }

    fun stop() {
        engine?.stop(300, 1000)
    }
}

/** Annuncia il telefono in rete locale (mDNS) così il tablet lo trova senza IP. */
class NsdAdvertiser(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val listener = object : NsdManager.RegistrationListener {
        override fun onServiceRegistered(info: NsdServiceInfo) {}
        override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        override fun onServiceUnregistered(info: NsdServiceInfo) {}
        override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
    }

    fun register(port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = "BoothCamera"
            serviceType = "_boothcam._tcp."
            setPort(port)
        }
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    fun unregister() {
        runCatching { nsd.unregisterService(listener) }
    }
}
