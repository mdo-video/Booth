package it.mdo.booth.camera

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Registra MP4 in locale (qualità piena) e produce frame JPEG leggeri per la preview sul tablet.
 * L'audio usa il microfono predefinito: con il ricevitore DJI Mic Mini in USB-C
 * Android lo instrada automaticamente come ingresso.
 */
class CameraController(
    private val context: Context,
    private val owner: LifecycleOwner,
    private val wantsFrames: () -> Boolean,
    private val onPreviewFrame: (ByteArray) -> Unit,
    private val onState: (String) -> Unit,
) {
    companion object {
        const val MAX_DURATION_MS = 60_000L
        const val PREVIEW_FPS = 15
        const val JPEG_QUALITY = 60
        val QUALITY: Quality = Quality.FHD   // Quality.UHD per il 4K
    }

    private val main = Handler(Looper.getMainLooper())
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val prefs = context.getSharedPreferences("booth", Context.MODE_PRIVATE)
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lastFrameMs = 0L
    private val autoStop = Runnable { stopRecording() }

    fun start() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val provider = future.get()

            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(QUALITY, FallbackStrategy.lowerQualityOrHigherThan(QUALITY))
                )
                .build()
            val video = VideoCapture.withOutput(recorder)

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                Size(1280, 720),
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                            )
                        ).build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()
            analysis.setAnalyzer(analysisExecutor, ::analyze)

            provider.unbindAll()
            provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, video, analysis)
            videoCapture = video
            onState("READY")
        }, ContextCompat.getMainExecutor(context))
    }

    private fun analyze(image: ImageProxy) {
        image.use {
            val now = System.currentTimeMillis()
            if (!wantsFrames() || now - lastFrameMs < 1000 / PREVIEW_FPS) return
            lastFrameMs = now
            val bmp = it.toBitmap()
            val rot = it.imageInfo.rotationDegrees
            val out = if (rot != 0) {
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            } else bmp
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, bos)
            onPreviewFrame(bos.toByteArray())
        }
    }

    @SuppressLint("MissingPermission")
    fun startRecording() {
        val video = videoCapture ?: return
        if (recording != null) return

        val n = prefs.getInt("counter", 0) + 1
        prefs.edit().putInt("counter", n).apply()
        val name = "dedica_%03d".format(n)

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Booth")
        }
        val options = MediaStoreOutputOptions.Builder(
            context.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        recording = video.output.prepareRecording(context, options)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(context)) { e ->
                when (e) {
                    is VideoRecordEvent.Start -> onState("RECORDING")
                    is VideoRecordEvent.Finalize -> {
                        main.removeCallbacks(autoStop)
                        recording = null
                        onState(if (e.hasError()) "ERROR:${e.error}" else "SAVED:$name.mp4")
                    }
                    else -> Unit
                }
            }
        main.postDelayed(autoStop, MAX_DURATION_MS)
    }

    fun stopRecording() {
        recording?.stop()
    }

    fun release() {
        main.removeCallbacks(autoStop)
        recording?.stop()
        analysisExecutor.shutdown()
    }
}
