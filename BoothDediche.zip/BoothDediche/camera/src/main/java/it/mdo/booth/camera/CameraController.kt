package it.mdo.booth.camera

import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.core.FocusMeteringAction
import android.os.BatteryManager
import android.content.IntentFilter
import android.content.Intent
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Registra in un file temporaneo ("take"). Il tablet lo rivede in streaming e poi decide:
 * SAVE (copia in galleria Movies/Booth) o DISCARD (cancella). Tutte le impostazioni
 * arrivano dal tablet e vengono ricordate qui.
 */
class CameraController(
    private val context: Context,
    private val owner: LifecycleOwner,
    private val wantsFrames: () -> Boolean,
    private val onPreviewFrame: (ByteArray) -> Unit,
    private val onState: (String) -> Unit,   // persistente: READY | RECORDING | TAKE:file | TAKE_SAVED:file:nome
    private val onEvent: (String) -> Unit,   // una tantum: SAVED:nome | ERROR:x
    private val onInfo: (String) -> Unit,    // JSON con capacità e impostazioni correnti
    private val onOrientation: (String) -> Unit = {},  // landscape | portrait
) {
    companion object {
        const val PREVIEW_FPS = 15
        const val JPEG_QUALITY = 60
        private val QUALITIES = linkedMapOf("HD" to Quality.HD, "FHD" to Quality.FHD, "UHD" to Quality.UHD)
    }

    private val main = Handler(Looper.getMainLooper())
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val io = Executors.newSingleThreadExecutor()
    private val prefs = context.getSharedPreferences("booth", Context.MODE_PRIVATE)
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    @Volatile private var pendingTake: File? = null
    private var savedName: String? = null
    @Volatile private var saving = false
    private var lastFrameMs = 0L
    private val autoStop = Runnable { stopRecording() }

    // impostazioni (persistenti)
    private var quality = prefs.getString("quality", "FHD") ?: "FHD"
    private var durationSec = prefs.getInt("duration", 60)
    private var zoom = prefs.getFloat("zoom", 1f)
    private var torch = prefs.getBoolean("torch", false)
    private var ev = prefs.getInt("ev", 0)
    private var prefix = prefs.getString("prefix", "dedica") ?: "dedica"
    private var counter = prefs.getInt("counter", 0)
    private var orientation = prefs.getString("orientation", "landscape") ?: "landscape"
    private var lock = false  // fuoco, esposizione e bianco bloccati (non persistente)

    private val audioCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = publishInfo()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = publishInfo()
    }

    private val takesDir: File
        get() = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir

    private val historyDir: File
        get() = File(context.getExternalFilesDir(null) ?: context.filesDir, "history").apply { mkdirs() }

    /** File dello storico (video .mp4 o miniatura .jpg) per nome. */
    fun historyFile(name: String): File? {
        val clean = File(name).name
        if (!clean.endsWith(".mp4") && !clean.endsWith(".jpg")) return null
        return File(historyDir, clean).takeIf { it.isFile }
    }

    /** Elenco JSON dei video salvati, dal più recente. */
    fun historyJson(): String {
        val arr = JSONArray()
        historyDir.listFiles { f -> f.name.endsWith(".mp4") }
            ?.sortedByDescending { it.lastModified() }
            ?.forEach { arr.put(JSONObject().put("name", it.name).put("time", it.lastModified())) }
        return arr.toString()
    }

    /** Copia il video nello storico, crea la miniatura e tiene solo gli ultimi 50. */
    private fun keepInHistory(src: File, name: String) {
        runCatching {
            val dst = File(historyDir, name)
            src.copyTo(dst, overwrite = true)
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(dst.absolutePath)
                r.getFrameAtTime(500_000)?.let { bmp ->
                    val w = 360
                    val h = (bmp.height * w / bmp.width.toFloat()).toInt().coerceAtLeast(1)
                    val small = Bitmap.createScaledBitmap(bmp, w, h, true)
                    File(historyDir, name.removeSuffix(".mp4") + ".jpg").outputStream().use {
                        small.compress(Bitmap.CompressFormat.JPEG, 80, it)
                    }
                }
            } finally {
                r.release()
            }
            historyDir.listFiles { f -> f.name.endsWith(".mp4") }
                ?.sortedByDescending { it.lastModified() }
                ?.drop(50)
                ?.forEach {
                    it.delete()
                    File(historyDir, it.name.removeSuffix(".mp4") + ".jpg").delete()
                }
        }
    }

    fun start() {
        takesDir.listFiles()?.filter { it.name.startsWith("take_") }?.forEach { it.delete() }
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            provider = future.get()
            if (orientation != "landscape") {
                onOrientation(orientation)
                main.postDelayed({ bind() }, 700)
            } else {
                bind()
            }
            audio.registerAudioDeviceCallback(audioCallback, main)
            onState("READY")
        }, ContextCompat.getMainExecutor(context))
    }

    private fun bind() {
        val p = provider ?: return
        val q = QUALITIES[quality] ?: Quality.FHD
        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q)))
            .build()
        val video = VideoCapture.withOutput(recorder)

        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(1280, 720),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                        )
                    ).build()
            )
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .build()
        analysis.setAnalyzer(analysisExecutor, ::analyze)

        p.unbindAll()
        val cam = p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, video, analysis)
        camera = cam
        videoCapture = video
        cam.cameraInfo.zoomState.observe(owner) { publishInfo() }
        applyControls()
        if (lock) applyLock()
        publishInfo()
    }

    private fun applyLock() {
        val cam = camera ?: return
        if (lock) {
            val point = SurfaceOrientedMeteringPointFactory(1f, 1f).createPoint(0.5f, 0.5f)
            val flags = FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB
            cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point, flags).disableAutoCancel().build())
        } else {
            cam.cameraControl.cancelFocusAndMetering()
        }
    }

    private fun applyControls() {
        val cam = camera ?: return
        val info = cam.cameraInfo
        info.zoomState.value?.let { zs ->
            zoom = zoom.coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
            cam.cameraControl.setZoomRatio(zoom)
        }
        if (info.hasFlashUnit()) cam.cameraControl.enableTorch(torch)
        val es = info.exposureState
        if (es.isExposureCompensationSupported) {
            ev = ev.coerceIn(es.exposureCompensationRange.lower, es.exposureCompensationRange.upper)
            cam.cameraControl.setExposureCompensationIndex(ev)
        }
    }

    private fun lenses(): List<Double> {
        val zs = camera?.cameraInfo?.zoomState?.value
        val lo = zs?.minZoomRatio ?: 1f
        val hi = zs?.maxZoomRatio ?: 1f
        val out = mutableListOf<Double>()
        if (lo < 0.95f) out += Math.ceil(lo * 10.0) / 10.0
        out += 1.0
        for (c in listOf(2.0, 3.0, 5.0, 10.0)) if (c <= hi + 0.01) out += c
        return out
    }

    private fun usbMicName(): String {
        val d = audio.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull {
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        return d?.productName?.toString() ?: ""
    }

    private fun publishInfo() {
        val cam = camera ?: return
        val info = cam.cameraInfo
        val supported = runCatching { QualitySelector.getSupportedQualities(info) }.getOrDefault(emptyList())
        val qs = QUALITIES.filter { (_, q) -> q in supported }.keys.toList()
        val es = info.exposureState
        val j = JSONObject()
        j.put("quality", quality)
        j.put("qualities", JSONArray(qs))
        j.put("duration", durationSec)
        j.put("zoom", (info.zoomState.value?.zoomRatio ?: zoom).toDouble())
        j.put("lenses", JSONArray(lenses()))
        j.put("hasTorch", info.hasFlashUnit())
        j.put("torch", torch)
        j.put("evSupported", es.isExposureCompensationSupported)
        j.put("ev", ev)
        j.put("evMin", es.exposureCompensationRange.lower)
        j.put("evMax", es.exposureCompensationRange.upper)
        j.put("prefix", prefix)
        j.put("counter", counter)
        j.put("mic", usbMicName())
        j.put("lock", lock)
        j.put("zoomMin", (info.zoomState.value?.minZoomRatio ?: 1f).toDouble())
        j.put("zoomMax", (info.zoomState.value?.maxZoomRatio ?: 1f).toDouble())
        j.put("orientation", orientation)
        runCatching {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            j.put("battery", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
            val st = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                ?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            j.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
            j.put("freeMb", takesDir.usableSpace / (1024L * 1024L))
        }
        onInfo(j.toString())
    }

    fun refreshInfo() = publishInfo()

    fun applySettings(j: JSONObject) {
        var rebind = false
        if (j.has("quality") && recording == null) {
            val q = j.getString("quality")
            if (q != quality && QUALITIES.containsKey(q)) { quality = q; rebind = true }
        }
        if (j.has("duration")) durationSec = j.getInt("duration").coerceIn(5, 600)
        if (j.has("zoom")) zoom = j.getDouble("zoom").toFloat()
        if (j.has("torch")) torch = j.getBoolean("torch")
        if (j.has("ev")) ev = j.getInt("ev")
        if (j.has("prefix")) {
            prefix = j.getString("prefix").filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(30)
            if (prefix.isEmpty()) prefix = "dedica"
        }
        if (j.has("counter")) counter = j.getInt("counter").coerceAtLeast(0)
        if (j.has("lock")) {
            val n = j.getBoolean("lock")
            if (n != lock) { lock = n; applyLock() }
        }
        if (j.has("orientation") && recording == null) {
            val o = j.getString("orientation")
            if ((o == "landscape" || o == "portrait") && o != orientation) {
                orientation = o
                prefs.edit().putString("orientation", o).apply()
                onOrientation(o)
                main.postDelayed({ bind() }, 700)
            }
        }
        prefs.edit()
            .putString("quality", quality).putInt("duration", durationSec)
            .putFloat("zoom", zoom).putBoolean("torch", torch).putInt("ev", ev)
            .putString("prefix", prefix).putInt("counter", counter)
            .apply()
        if (rebind) bind() else { applyControls(); publishInfo() }
    }

    private fun analyze(image: ImageProxy) {
        image.use {
            val now = System.currentTimeMillis()
            if (!wantsFrames() || now - lastFrameMs < 1000 / PREVIEW_FPS) return
            lastFrameMs = now
            val bmp = it.toBitmap()
            val rot = it.imageInfo.rotationDegrees
            val out = if (rot != 0) {
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            } else bmp
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, bos)
            onPreviewFrame(bos.toByteArray())
        }
    }

    @SuppressLint("MissingPermission")
    fun startRecording() {
        val video = videoCapture ?: return
        if (recording != null || pendingTake != null) return
        takesDir.listFiles()?.filter { it.name.startsWith("take_") }?.forEach { it.delete() }
        val file = File(takesDir, "take_${System.currentTimeMillis()}.mp4")

        recording = video.output.prepareRecording(context, FileOutputOptions.Builder(file).build())
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(context)) { e ->
                when (e) {
                    is VideoRecordEvent.Start -> onState("RECORDING")
                    is VideoRecordEvent.Finalize -> {
                        main.removeCallbacks(autoStop)
                        recording = null
                        if (e.hasError()) {
                            file.delete()
                            onEvent("ERROR:${e.error}")
                            onState("READY")
                        } else {
                            pendingTake = file
                            savedName = null
                            onState("TAKE:${file.name}")
                        }
                    }
                    else -> Unit
                }
            }
        main.postDelayed(autoStop, durationSec * 1000L)
    }

    fun stopRecording() {
        recording?.stop()
    }

    fun takeFile(name: String): File? = pendingTake?.takeIf { it.name == name }

    /** Copia il take in galleria (Movies/Booth) con numerazione progressiva. */
    fun saveTake() {
        val src = pendingTake ?: return
        if (savedName != null || saving) return
        saving = true
        io.execute {
            try {
                val n = counter + 1
                val name = "%s_%03d.mp4".format(Locale.ROOT, prefix, n)
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Booth")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("insert")
                resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                keepInHistory(src, name)
                main.post {
                    counter = n
                    savedName = name
                    saving = false
                    prefs.edit().putInt("counter", counter).apply()
                    onEvent("SAVED:$name")
                    onState("TAKE_SAVED:${src.name}:$name")
                    publishInfo()
                }
            } catch (t: Throwable) {
                main.post {
                    saving = false
                    onEvent("ERROR:save")
                }
            }
        }
    }

    /** Elimina un video dallo storico (la copia in galleria resta). */
    fun deleteHistory(name: String) {
        val clean = File(name).name.removeSuffix(".mp4")
        File(historyDir, "$clean.mp4").delete()
        File(historyDir, "$clean.jpg").delete()
        onEvent("DELETED:$clean.mp4")
    }

    /** Rifai (take non salvato) oppure chiudi l'anteprima dopo il salvataggio. */
    fun discardTake() {
        if (recording != null || saving) return
        pendingTake?.delete()
        pendingTake = null
        savedName = null
        onState("READY")
    }

    fun release() {
        main.removeCallbacks(autoStop)
        recording?.stop()
        runCatching { audio.unregisterAudioDeviceCallback(audioCallback) }
        analysisExecutor.shutdown()
        io.shutdown()
    }
}
