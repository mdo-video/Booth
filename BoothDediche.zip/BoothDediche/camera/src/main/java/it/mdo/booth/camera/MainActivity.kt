package it.mdo.booth.camera

import android.content.pm.ActivityInfo
import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private var camera: CameraController? = null
    private var server: StreamServer? = null
    private var nsd: NsdAdvertiser? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status = TextView(this).apply {
            textSize = 22f
            setPadding(48, 48, 48, 48)
            text = "Booth Camera"
        }
        setContentView(status)

        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) boot() else status.text = "Servono permessi camera e microfono"
        }.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun boot() {
        val srv = StreamServer(
            takeFile = { name -> camera?.takeFile(name) },
            onCommand = { cmd -> runOnUiThread { handle(cmd) } },
            historyFile = { name -> camera?.historyFile(name) },
            historyList = { camera?.historyJson() ?: "[]" },
            thumbFile = { name -> camera?.thumbFile(name) },
            onFrame = { bytes -> camera?.saveFrame(bytes) ?: false },
        )
        val cam = CameraController(
            context = this,
            owner = this,
            wantsFrames = srv::hasClients,
            onPreviewFrame = srv::sendFrame,
            onState = { s ->
                srv.sendState(s)
                runOnUiThread { status.text = "Booth Camera\nStato: $s" }
            },
            onEvent = srv::sendEvent,
            onInfo = srv::sendInfo,
            onOrientation = { o ->
                runOnUiThread {
                    requestedOrientation = if (o == "portrait") ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                }
            },
        )
        server = srv
        camera = cam
        srv.start()
        cam.start()
        nsd = NsdAdvertiser(this).also { it.register(StreamServer.PORT) }
    }

    private fun handle(cmd: String) {
        val cam = camera ?: return
        when {
            cmd == "START" -> cam.startRecording()
            cmd == "PHOTO" -> cam.takePhoto()
            cmd == "STOP" -> cam.stopRecording()
            cmd == "SAVE" -> cam.saveTake()
            cmd == "DISCARD" -> cam.discardTake()
            cmd == "INFO?" -> cam.refreshInfo()
            cmd.startsWith("DEL:") -> cam.deleteHistory(cmd.removePrefix("DEL:"))
            cmd.startsWith("SET:") -> runCatching { cam.applySettings(JSONObject(cmd.removePrefix("SET:"))) }
        }
    }

    override fun onDestroy() {
        camera?.release()
        server?.stop()
        nsd?.unregister()
        super.onDestroy()
    }
}
