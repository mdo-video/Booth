package it.mdo.booth.camera

import android.content.pm.ActivityInfo
import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var updText: TextView
    private lateinit var updBtn: Button
    private lateinit var updates: UpdateManager
    private var camera: CameraController? = null
    private var server: StreamServer? = null
    private var nsd: NsdAdvertiser? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status = TextView(this).apply {
            textSize = 22f
            setPadding(48, 48, 48, 48)
            text = "Booth Camera"
        }
        updText = TextView(this).apply { textSize = 16f; setPadding(48, 0, 48, 16) }
        updBtn = Button(this).apply { text = "Controlla aggiornamenti" }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(updText)
            addView(updBtn)
        }
        setContentView(root)

        updates = UpdateManager(this, "booth-camera.apk")
        updates.listener = { st ->
            runOnUiThread {
                updText.text = st.text
                updBtn.isEnabled = !st.busy
                updBtn.text = if (st.canInstall) "Installa aggiornamento" else "Controlla aggiornamenti"
            }
        }
        updBtn.setOnClickListener {
            if (updates.status.value.canInstall) updates.installNow() else updates.check()
        }
        updText.text = updates.status.value.text
        updates.check()

        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) boot() else status.text = "Servono permessi camera e microfono"
        }.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun boot() {
        val srv = StreamServer(
            takeFile = { name -> camera?.takeFile(name) },
            onCommand = { cmd -> runOnUiThread { handle(cmd) } },
            historyFile = { name -> camera?.historyFile(name) },
            historyList = { camera?.historyJson() ?: "[]" },
            thumbFile = { name -> camera?.thumbFile(name) },
            onFrame = { bytes -> camera?.saveFrame(bytes) ?: false },
        )
        val cam = CameraController(
            context = this,
            owner = this,
            wantsFrames = srv::hasClients,
            onPreviewFrame = srv::sendFrame,
            onState = { s ->
                srv.sendState(s)
                runOnUiThread { status.text = "Booth Camera\nStato: $s" }
            },
            onEvent = srv::sendEvent,
            onInfo = srv::sendInfo,
            onOrientation = { o ->
                runOnUiThread {
                    requestedOrientation = if (o == "portrait") ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                }
            },
        )
        server = srv
        camera = cam
        srv.start()
        cam.start()
        nsd = NsdAdvertiser(this).also { it.register(StreamServer.PORT) }
    }

    private fun handle(cmd: String) {
        val cam = camera ?: return
        when {
            cmd == "START" -> cam.startRecording()
            cmd == "PHOTO" -> cam.takePhoto()
            cmd == "STOP" -> cam.stopRecording()
            cmd == "SAVE" -> cam.saveTake()
            cmd == "DISCARD" -> cam.discardTake()
            cmd == "INFO?" -> cam.refreshInfo()
            cmd.startsWith("DEL:") -> cam.deleteHistory(cmd.removePrefix("DEL:"))
            cmd.startsWith("SET:") -> runCatching { cam.applySettings(JSONObject(cmd.removePrefix("SET:"))) }
        }
    }

    override fun onDestroy() {
        camera?.release()
        server?.stop()
        nsd?.unregister()
        super.onDestroy()
    }
}
