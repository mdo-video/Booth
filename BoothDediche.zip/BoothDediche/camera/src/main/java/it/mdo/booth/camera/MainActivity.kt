package it.mdo.booth.camera

import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private var camera: CameraController? = null
    private var server: StreamServer? = null
    private var nsd: NsdAdvertiser? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status = TextView(this).apply {
            textSize = 22f
            setPadding(48, 48, 48, 48)
            text = "Booth Camera"
        }
        setContentView(status)

        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) boot() else status.text = "Servono permessi camera e microfono"
        }.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun boot() {
        val srv = StreamServer { cmd ->
            runOnUiThread {
                when (cmd) {
                    "START" -> camera?.startRecording()
                    "STOP" -> camera?.stopRecording()
                }
            }
        }
        val cam = CameraController(
            context = this,
            owner = this,
            wantsFrames = srv::hasClients,
            onPreviewFrame = srv::sendFrame,
            onState = { s ->
                srv.sendState(s)
                runOnUiThread { status.text = "Booth Camera\nStato: $s" }
            },
        )
        server = srv
        camera = cam
        srv.start()
        cam.start()
        nsd = NsdAdvertiser(this).also { it.register(StreamServer.PORT) }
    }

    override fun onDestroy() {
        camera?.release()
        server?.stop()
        nsd?.unregister()
        super.onDestroy()
    }
}
