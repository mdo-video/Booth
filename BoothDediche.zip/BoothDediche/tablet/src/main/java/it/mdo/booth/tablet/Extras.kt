package it.mdo.booth.tablet

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONObject

/** Batteria e spazio libero del telefono; diventa rosso quando serve attenzione. */
@Composable
fun StatusBadge(info: JSONObject, modifier: Modifier = Modifier) {
    val bat = info.optInt("battery", -1)
    val charging = info.optBoolean("charging")
    val freeMb = info.optLong("freeMb", -1L)
    if (bat < 0 && freeMb < 0) return
    val lowBat = bat in 0..19 && !charging
    val lowSpace = freeMb in 0..1999
    val warn = lowBat || lowSpace
    Column(
        modifier.clip(RoundedCornerShape(12.dp))
            .background(if (warn) Color(0xDDB71C1C) else Color(0x66000000))
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        val battery = if (bat >= 0) "🔋 $bat%" + (if (charging) " ⚡" else "") else ""
        val space = if (freeMb >= 0) "💾 " + "%.1f".format(freeMb / 1024.0) + " GB" else ""
        Text("$battery   $space".trim(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        if (lowBat) Text("Batteria del telefono bassa!", color = Color.White, fontSize = 14.sp)
        if (lowSpace) Text("Spazio del telefono quasi finito!", color = Color.White, fontSize = 14.sp)
    }
}

/** Codice QR a tutto schermo: l'ospite lo inquadra per scaricare il video (stesso Wi-Fi). */
@Composable
fun QrOverlay(url: String, onClose: () -> Unit) {
    val bmp = remember(url) { makeQr(url, 720) }
    Box(
        Modifier.fillMaxSize().background(Color(0xDD000000)).clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClose,
        ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.clip(RoundedCornerShape(24.dp)).background(Color.White).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            bmp?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.size(340.dp)) }
            Spacer(Modifier.height(12.dp))
            Text("Inquadra col telefono per scaricare il video", color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Serve essere collegati allo stesso Wi-Fi", color = Color.DarkGray, fontSize = 16.sp)
            Text("Tocca per chiudere", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

private fun makeQr(text: String, size: Int): Bitmap? = runCatching {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
    Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
}.getOrNull()
