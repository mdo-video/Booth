package it.mdo.booth.tablet

import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.DisposableEffect
import android.media.ToneGenerator
import android.media.AudioManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import org.json.JSONObject
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun BoothScreen(
    client: BoothClient,
    local: LocalSettings,
    frames: FrameStore,
    onKiosk: (Boolean) -> Unit,
    onShare: (String, String, (Float) -> Unit, (Boolean) -> Unit) -> Unit,
    onPickFrame: () -> Unit,
    dashCfg: DashConfig,
) {
    val connected by client.connected.collectAsState()
    val state by client.state.collectAsState()
    val info by client.info.collectAsState()
    val history by client.history.collectAsState()

    var starting by remember { mutableStateOf(false) }
    var countdown by remember { mutableIntStateOf(0) }
    var remaining by remember { mutableIntStateOf(60) }
    var banner by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<HistoryItem?>(null) }
    var qr by remember { mutableStateOf<QrRequest?>(null) }
    var shotKind by remember { mutableStateOf("video") }
    var shareProgress by remember { mutableStateOf<Float?>(null) }
    var shareResult by remember { mutableStateOf<Boolean?>(null) }
    val sharing = shareProgress != null

    val parts = state.split(":")
    val recording = state == "RECORDING"
    val processing = parts[0] == "PROCESSING"
    val processingPct = parts.getOrNull(1)?.toIntOrNull() ?: 0
    val frameActive = info?.optBoolean("frame") == true
    val frameOverlay = remember(frames.bitmap, frameActive) { if (frameActive) frames.bitmap?.asImageBitmap() else null }
    val phoneFrameId = info?.optString("frameId") ?: ""
    val hasInfo = info != null
    val hasTake = (parts[0] == "TAKE" || parts[0] == "TAKE_SAVED") && parts.size > 1
    val takeSaved = parts[0] == "TAKE_SAVED"
    val takeFile = parts.getOrNull(1) ?: ""
    val savedName = parts.getOrNull(2)
    val maxSec = info?.optInt("duration", 60) ?: 60
    val base = client.baseUrl
    val tone = remember { runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 80) }.getOrNull() }
    DisposableEffect(Unit) { onDispose { tone?.release() } }

    LaunchedEffect(starting) {
        if (starting) {
            for (i in local.countdown downTo 1) {
                countdown = i
                if (local.sound) tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
                delay(1000)
            }
            countdown = 0
            if (local.sound) tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, 400)
            EventLog.add(if (shotKind == "photo") "FOTO" else "REC_START")
            client.send(if (shotKind == "photo") "PHOTO" else "START")
            starting = false
        }
    }
    LaunchedEffect(recording) { if (recording) { viewing = null; qr = null } }
    // la cornice del tablet viene mandata al telefono se questo non ha la stessa
    LaunchedEffect(connected, hasInfo, phoneFrameId, frames.id) {
        val data = frames.bytes
        if (connected && hasInfo && data != null && frames.id.isNotEmpty() && phoneFrameId != frames.id) {
            client.uploadFrame(data) { }
        }
    }
    // ...e quando il telefono ce l'ha, dopo un'importazione si accende da sola
    LaunchedEffect(connected, phoneFrameId, frames.id, frames.enableOnSync) {
        if (connected && frames.enableOnSync && frames.id.isNotEmpty() && phoneFrameId == frames.id) {
            frames.enableOnSync = false
            client.set(JSONObject().put("frame", true))
        }
    }
    LaunchedEffect(takeSaved, savedName) {
        if (takeSaved && savedName != null && local.autoQr && base != null) qr = QrRequest("$base/h/$savedName")
    }
    LaunchedEffect(connected) {
        if (connected) while (true) { client.send("INFO?"); delay(30_000) }
    }
    LaunchedEffect(recording) {
        if (recording) {
            remaining = maxSec
            while (remaining > 0) { delay(1000); remaining-- }
        }
    }
    LaunchedEffect(Unit) {
        client.events.collect { ev ->
            if (ev.startsWith("MOTION:") && dashCfg.motion) {
                EventLog.add(if (ev == "MOTION:FALL") "CAMERA_CADUTA" else "CAMERA_SPOSTATA")
            }
            banner = when {
                ev == "MOTION:FALL" -> "⚠ Il telefono camera è caduto!"
                ev == "MOTION:MOVED" -> "⚠ Il telefono camera è stato spostato"
                ev.startsWith("SAVED:") -> "Salvata ✓  " + ev.removePrefix("SAVED:")
                ev.startsWith("ERROR") -> "Errore: " + ev.removePrefix("ERROR:")
                else -> null
            }
        }
    }
    LaunchedEffect(shareResult) {
        if (shareResult != null) { delay(3000); shareResult = null }
    }
    LaunchedEffect(banner) {
        if (banner != null) { delay(3000); banner = null }
    }
    // registro eventi e stato per l'app di controllo
    LaunchedEffect(connected) { DashState.phoneConnected = connected; EventLog.phone(connected) }
    LaunchedEffect(info) { DashState.phoneInfo = info?.toString() ?: "" }
    LaunchedEffect(state) { EventLog.stateChange(state) }
    LaunchedEffect(qr) { if (qr != null) EventLog.add("QR") }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        LivePreview(client, local, frameOverlay)
        if (!connected) {
            Text("Cerco il telefono…", color = Color.White, fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
        }
        if (countdown > 0) {
            Text("$countdown", color = Color.White, fontSize = 220.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
        }
        if (recording) {
            Text("${remaining}s", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
        }
        if (processing) {
            Column(
                Modifier.align(Alignment.Center).clip(RoundedCornerShape(28.dp)).background(Color(0xCC000000)).padding(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Applico la cornice…", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("$processingPct%", color = Color(0xFFFFC107), fontSize = 56.sp, fontWeight = FontWeight.Bold)
            }
        }
        banner?.let {
            Text(it, color = Color(0xFF66BB6A), fontSize = 36.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
        }

        // tasto impostazioni
        if (!recording && !starting && !processing && countdown == 0) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(20.dp).size(56.dp).clip(CircleShape)
                    .background(Color(0x66000000))
                    .clickable { showSettings = true; client.send("INFO?") },
                contentAlignment = Alignment.Center,
            ) {
                Text("⚙", color = Color.White, fontSize = 28.sp)
            }
            Box(
                Modifier.align(Alignment.TopEnd).padding(top = 20.dp, end = 92.dp).size(56.dp).clip(CircleShape)
                    .background(Color(0x66000000))
                    .clickable { qr = QrRequest(null) },
                contentAlignment = Alignment.Center,
            ) {
                Text("QR", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        // tasto REC (nascosto mentre c'è un'anteprima da valutare)
        if (!hasTake && !processing) {
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp), contentAlignment = Alignment.Center) {
                if (recording) {
                    CircularProgressIndicator(
                        progress = { remaining / maxSec.toFloat() },
                        modifier = Modifier.size(200.dp),
                        color = Color(0xFFE53935),
                        strokeWidth = 8.dp,
                    )
                }
                val enabled = connected && !starting
                Box(
                    Modifier.size(160.dp).clip(CircleShape)
                        .background(if (enabled) Color(0xFFE53935) else Color.Gray)
                        .clickable(enabled = enabled) {
                            if (recording) client.send("STOP") else { shotKind = "video"; starting = true }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(if (recording) "STOP" else "REC", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // tasto FOTO
        if (!hasTake && !processing && connected && !recording && !starting && countdown == 0 && info?.optBoolean("hasPhoto") == true) {
            Box(
                Modifier.align(Alignment.BottomCenter).offset(x = 170.dp).padding(bottom = 72.dp)
                    .size(96.dp).clip(CircleShape).background(Color(0xFF1565C0))
                    .clickable { shotKind = "photo"; starting = true },
                contentAlignment = Alignment.Center,
            ) {
                Text("📷", fontSize = 40.sp)
            }
        }

        // anteprima del video appena registrato
        if (hasTake && base != null) {
            TakeCard(
                client = client,
                path = "/take/$takeFile",
                cacheKey = takeFile,
                saved = takeSaved,
                savedName = savedName,
                sharing = sharing,
                onRedo = { EventLog.add("DEDICA_SCARTATA"); client.send("DISCARD") },
                onQr = { if (savedName != null) qr = QrRequest("$base/h/$savedName") },
                onSave = { client.send("SAVE") },
                onShare = {
                    shareResult = null
                    shareProgress = 0f
                    onShare(
                        "/take/$takeFile", savedName ?: (if (takeFile.endsWith(".jpg")) "dedica.jpg" else "dedica.mp4"),
                        { p -> shareProgress = p },
                        { ok -> shareProgress = null; shareResult = ok; EventLog.add(if (ok) "CONDIVISA" else "CONDIVISIONE_FALLITA") },
                    )
                },
                modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
            )
        }

        // torcia e focali
        if (!hasTake && !processing && connected && viewing == null) {
            info?.let { CameraControls(client, it, Modifier.align(Alignment.CenterEnd).padding(top = 96.dp, bottom = 96.dp, end = 24.dp)) }
        }

        // batteria e spazio del telefono
        if (connected) {
            info?.let { StatusBadge(it, Modifier.align(Alignment.TopStart).padding(20.dp)) }
        }

        // messaggio d'attesa
        if (connected && state == "READY" && !starting && countdown == 0 && !hasTake && viewing == null &&
            local.welcome.isNotBlank()
        ) {
            Text(
                local.welcome,
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 240.dp)
                    .clip(RoundedCornerShape(24.dp)).background(Color(0x99000000))
                    .padding(horizontal = 28.dp, vertical = 14.dp),
            )
        }

        // storico: pellicola verticale a sinistra
        if (!recording && !processing && countdown == 0 && history.isNotEmpty()) {
            HistoryStrip(
                client = client,
                list = history,
                selected = viewing?.name,
                onSelect = { viewing = it },
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 16.dp, top = 24.dp, bottom = 24.dp),
            )
        }
        viewing?.let { v ->
            if (!hasTake && base != null) {
                HistoryCard(
                    client = client,
                    path = "/h/${v.name}",
                    cacheKey = "h_${v.time}_${v.name}",
                    name = v.name,
                    sharing = sharing,
                    onClose = { viewing = null },
                    onQr = { qr = QrRequest("$base/h/${v.name}") },
                    onDelete = { EventLog.add("DEDICA_ELIMINATA", v.name); client.send("DEL:${v.name}"); viewing = null },
                    onShare = {
                        shareResult = null
                        shareProgress = 0f
                        onShare(
                            "/h/${v.name}", v.name,
                            { p -> shareProgress = p },
                            { ok -> shareProgress = null; shareResult = ok; EventLog.add(if (ok) "CONDIVISA" else "CONDIVISIONE_FALLITA") },
                        )
                    },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
                )
            }
        }

        // stato del trasferimento verso il tablet
        if (shareProgress != null || shareResult != null) {
            ShareStatus(shareProgress, shareResult, Modifier.align(Alignment.TopCenter).padding(top = 96.dp))
        }

        if (showSettings) {
            SettingsPanel(client, info, local, frames, onKiosk, onPickFrame, dashCfg) { showSettings = false }
        }

        qr?.let { r -> QrOverlay(wifiQrPayload(local.wifiSsid, local.wifiPass), r.videoUrl) { qr = null } }
    }
}
