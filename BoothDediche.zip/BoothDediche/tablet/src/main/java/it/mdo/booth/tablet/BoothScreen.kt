package it.mdo.booth.tablet

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun BoothScreen(
    client: BoothClient,
    local: LocalSettings,
    onKiosk: (Boolean) -> Unit,
    onShare: (String, String, (Float) -> Unit, (Boolean) -> Unit) -> Unit,
) {
    val connected by client.connected.collectAsState()
    val frame by client.frame.collectAsState()
    val state by client.state.collectAsState()
    val info by client.info.collectAsState()

    var starting by remember { mutableStateOf(false) }
    var countdown by remember { mutableIntStateOf(0) }
    var remaining by remember { mutableIntStateOf(60) }
    var banner by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var shareProgress by remember { mutableStateOf<Float?>(null) }
    var shareResult by remember { mutableStateOf<Boolean?>(null) }
    val sharing = shareProgress != null

    val parts = state.split(":")
    val recording = state == "RECORDING"
    val hasTake = (parts[0] == "TAKE" || parts[0] == "TAKE_SAVED") && parts.size > 1
    val takeSaved = parts[0] == "TAKE_SAVED"
    val takeFile = parts.getOrNull(1) ?: ""
    val savedName = parts.getOrNull(2)
    val maxSec = info?.optInt("duration", 60) ?: 60
    val base = client.baseUrl

    LaunchedEffect(starting) {
        if (starting) {
            for (i in local.countdown downTo 1) { countdown = i; delay(1000) }
            countdown = 0
            client.send("START")
            starting = false
        }
    }
    LaunchedEffect(recording) {
        if (recording) {
            remaining = maxSec
            while (remaining > 0) { delay(1000); remaining-- }
        }
    }
    LaunchedEffect(Unit) {
        client.events.collect { ev ->
            banner = when {
                ev.startsWith("SAVED:") -> "Salvata ✓  " + ev.removePrefix("SAVED:")
                ev.startsWith("ERROR") -> "Errore: " + ev.removePrefix("ERROR:")
                else -> null
            }
        }
    }
    LaunchedEffect(shareResult) {
        if (shareResult != null) { delay(3000); shareResult = null }
    }
    LaunchedEffect(banner) {
        if (banner != null) { delay(3000); banner = null }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        frame?.let { bmp ->
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = if (local.mirror) -1f else 1f },
                contentScale = ContentScale.Fit,
            )
        }
        if (!connected) {
            Text("Cerco il telefono…", color = Color.White, fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
        }
        if (countdown > 0) {
            Text("$countdown", color = Color.White, fontSize = 220.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
        }
        if (recording) {
            Text("${remaining}s", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
        }
        banner?.let {
            Text(it, color = Color(0xFF66BB6A), fontSize = 36.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
        }

        // tasto impostazioni
        if (!recording && !starting && countdown == 0) {
            Box(
                Modifier.align(Alignment.TopStart).padding(20.dp).size(56.dp).clip(CircleShape)
                    .background(Color(0x66000000))
                    .clickable { showSettings = true; client.send("INFO?") },
                contentAlignment = Alignment.Center,
            ) {
                Text("⚙", color = Color.White, fontSize = 28.sp)
            }
        }

        // tasto REC (nascosto mentre c'è un'anteprima da valutare)
        if (!hasTake) {
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp), contentAlignment = Alignment.Center) {
                if (recording) {
                    CircularProgressIndicator(
                        progress = { remaining / maxSec.toFloat() },
                        modifier = Modifier.size(200.dp),
                        color = Color(0xFFE53935),
                        strokeWidth = 8.dp,
                    )
                }
                val enabled = connected && !starting
                Box(
                    Modifier.size(160.dp).clip(CircleShape)
                        .background(if (enabled) Color(0xFFE53935) else Color.Gray)
                        .clickable(enabled = enabled) {
                            if (recording) client.send("STOP") else starting = true
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(if (recording) "STOP" else "REC", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // anteprima del video appena registrato
        if (hasTake && base != null) {
            TakeCard(
                url = "$base/take/$takeFile",
                saved = takeSaved,
                savedName = savedName,
                sharing = sharing,
                onRedo = { client.send("DISCARD") },
                onSave = { client.send("SAVE") },
                onShare = {
                    shareResult = null
                    shareProgress = 0f
                    onShare(
                        takeFile, savedName ?: "dedica.mp4",
                        { p -> shareProgress = p },
                        { ok -> shareProgress = null; shareResult = ok },
                    )
                },
                modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
            )
        }

        // torcia e focali
        if (!hasTake && connected) {
            info?.let { CameraControls(client, it, Modifier.align(Alignment.CenterEnd).padding(end = 24.dp)) }
        }

        // stato del trasferimento verso il tablet
        if (shareProgress != null || shareResult != null) {
            ShareStatus(shareProgress, shareResult, Modifier.align(Alignment.TopCenter).padding(top = 96.dp))
        }

        if (showSettings) {
            SettingsPanel(client, info, local, onKiosk) { showSettings = false }
        }
    }
}
