package it.mdo.booth.tablet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.TimeUnit

/** Trova il telefono via mDNS, si connette in WebSocket e riconnette da solo se cade. */
@Suppress("DEPRECATION")
class BoothClient(context: Context) {
    val connected = MutableStateFlow(false)
    val frame = MutableStateFlow<Bitmap?>(null)
    /** READY | RECORDING | SAVED:file | ERROR:x | OFFLINE */
    val state = MutableStateFlow("OFFLINE")

    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val http = OkHttpClient.Builder()
        .pingInterval(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private val main = Handler(Looper.getMainLooper())
    private var socket: WebSocket? = null
    private var target: NsdServiceInfo? = null
    private var resolving = false

    private val discovery = object : NsdManager.DiscoveryListener {
        override fun onServiceFound(info: NsdServiceInfo) {
            if (info.serviceType.contains("_boothcam") && !connected.value) resolve(info)
        }
        override fun onServiceLost(info: NsdServiceInfo) {}
        override fun onDiscoveryStarted(serviceType: String) {}
        override fun onDiscoveryStopped(serviceType: String) {}
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
    }

    fun start() {
        nsd.discoverServices("_boothcam._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery)
    }

    fun stop() {
        main.removeCallbacksAndMessages(null)
        runCatching { nsd.stopServiceDiscovery(discovery) }
        socket?.close(1000, null)
    }

    fun send(cmd: String) {
        socket?.send(cmd)
    }

    private fun resolve(info: NsdServiceInfo) {
        if (resolving) return
        resolving = true
        nsd.resolveService(info, object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, errorCode: Int) { resolving = false }
            override fun onServiceResolved(i: NsdServiceInfo) {
                resolving = false
                target = i
                main.post { connect() }
            }
        })
    }

    private fun connect() {
        val t = target ?: return
        val req = Request.Builder().url("ws://${t.host.hostAddress}:${t.port}/ws").build()
        socket = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                connected.value = true
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.startsWith("STATE:")) state.value = text.removePrefix("STATE:")
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val b = bytes.toByteArray()
                BitmapFactory.decodeByteArray(b, 0, b.size)?.let { frame.value = it }
            }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = lost(webSocket)
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) = lost(webSocket)
        })
    }

    private fun lost(ws: WebSocket) {
        if (ws !== socket) return
        connected.value = false
        state.value = "OFFLINE"
        main.postDelayed({ connect() }, 2000)
    }
}
