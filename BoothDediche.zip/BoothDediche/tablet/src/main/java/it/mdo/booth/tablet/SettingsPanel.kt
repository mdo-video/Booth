package it.mdo.booth.tablet

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt

private fun JSONObject.strList(key: String): List<String> =
    optJSONArray(key)?.let { a -> List(a.length()) { a.getString(it) } } ?: emptyList()

internal fun JSONObject.dblList(key: String): List<Double> =
    optJSONArray(key)?.let { a -> List(a.length()) { a.getDouble(it) } } ?: emptyList()

@Composable
fun SettingsPanel(
    client: BoothClient,
    info: JSONObject?,
    local: LocalSettings,
    onKiosk: (Boolean) -> Unit,
    onClose: () -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize().background(Color(0x99000000)).clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { onClose() }
        )
        Column(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(440.dp)
                .background(Color(0xFF16181D))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Impostazioni", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                Chip("Chiudi", false, onClose)
            }

            if (info == null) {
                Text("Telefono non connesso", color = Color.LightGray, fontSize = 16.sp)
            } else {
                PhoneSettings(client, info)
            }

            Section("TABLET")
            SwitchRow("Anteprima a specchio", local.mirror) { local.mirror = it; local.save() }
            Label("Conto alla rovescia")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 3, 5).forEach { s ->
                    Chip(if (s == 0) "Nessuno" else "${s}s", local.countdown == s) { local.countdown = s; local.save() }
                }
            }
            SwitchRow("Suoni del conto alla rovescia", local.sound) { local.sound = it; local.save() }
            Label("Messaggio di benvenuto")
            OutlinedTextField(
                value = local.welcome,
                onValueChange = { local.welcome = it.take(60); local.save() },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            )
            SwitchRow("Kiosk (blocca le altre app)", local.kiosk) { local.kiosk = it; local.save(); onKiosk(it) }
            Text("Condividere un video disattiva il kiosk.", color = Color.Gray, fontSize = 13.sp)
        }
    }
}

@Composable
private fun PhoneSettings(client: BoothClient, info: JSONObject) {
    fun send(key: String, value: Any) = client.set(JSONObject().put(key, value))

    val qualities = info.strList("qualities")
    if (qualities.isNotEmpty()) {
        Section("QUALITÀ VIDEO")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            qualities.forEach { q ->
                val label = when (q) {
                    "UHD" -> "4K"
                    "FHD" -> "Full HD"
                    else -> "HD"
                }
                Chip(label, info.optString("quality") == q) { send("quality", q) }
            }
        }
    }

    Section("DURATA MASSIMA")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(15, 30, 60, 90, 120).forEach { s ->
            Chip("${s}s", info.optInt("duration") == s) { send("duration", s) }
        }
    }

    Section("ORIENTAMENTO VIDEO")
    val orient = info.optString("orientation", "landscape")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Orizzontale", orient == "landscape") { send("orientation", "landscape") }
        Chip("Verticale", orient == "portrait") { send("orientation", "portrait") }
    }
    Text("Ruota il telefono nella posizione scelta.", color = Color.Gray, fontSize = 14.sp)

    Section("OBIETTIVO")
    Text(
        "Il telefono dichiara zoom da " + "%.1f".format(info.optDouble("zoomMin", 1.0)) +
            "x a " + "%.1f".format(info.optDouble("zoomMax", 1.0)) + "x",
        color = Color.Gray, fontSize = 14.sp,
    )
    val lenses = info.dblList("lenses")
    if (lenses.size > 1) {
        val cur = info.optDouble("zoom", 1.0)
        val sel = lenses.minByOrNull { abs(it - cur) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            lenses.forEach { z -> Chip(formatZoom(z), z == sel) { send("zoom", z) } }
        }
    } else {
        Text("Il telefono espone una sola ottica alle app.", color = Color.Gray, fontSize = 14.sp)
    }

    if (info.optBoolean("hasTorch")) {
        SwitchRow("Torcia (luce continua)", info.optBoolean("torch")) { send("torch", it) }
    }

    if (info.optBoolean("evSupported") && info.optInt("evMax") > info.optInt("evMin")) {
        val lo = info.optInt("evMin")
        val hi = info.optInt("evMax")
        var ev by remember(info.optInt("ev")) { mutableFloatStateOf(info.optInt("ev").toFloat()) }
        Label("Esposizione: ${ev.roundToInt()}")
        Slider(
            value = ev,
            onValueChange = { ev = it },
            onValueChangeFinished = { send("ev", ev.roundToInt()) },
            valueRange = lo.toFloat()..hi.toFloat(),
            steps = hi - lo - 1,
        )
    }

    Section("NOME FILE")
    var prefix by remember(info.optString("prefix")) { mutableStateOf(info.optString("prefix", "dedica")) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = prefix,
            onValueChange = { prefix = it.filter { c -> c.isLetterOrDigit() || c == '_' || c == '-' }.take(30) },
            singleLine = true,
            modifier = Modifier.weight(1f),
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
        )
        Chip("Applica", false) { send("prefix", prefix) }
    }
    val next = info.optInt("counter") + 1
    Label("Prossimo file: ${info.optString("prefix")}_${"%03d".format(next)}.mp4")
    Row { Chip("Azzera numerazione", false) { send("counter", 0) } }

    Section("MICROFONO")
    val mic = info.optString("mic")
    Label(if (mic.isNotEmpty()) "USB collegato: $mic" else "Microfono del telefono (nessun USB rilevato)")
}

private fun formatZoom(z: Double): String =
    if (z == z.toInt().toDouble()) "${z.toInt()}x" else "${z}x"

@Composable
private fun Section(title: String) =
    Text(title, color = Color(0xFF9AA0A6), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)

@Composable
private fun Label(text: String) = Text(text, color = Color.White, fontSize = 18.sp)

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) Color(0xFFE53935) else Color(0xFF2B2F36))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(text, color = Color.White, fontSize = 16.sp)
    }
}
