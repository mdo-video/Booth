package it.mdo.booth.tablet

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File

/** Impostazioni che restano sul tablet. */
class LocalSettings(private val prefs: SharedPreferences) {
    var mirror by mutableStateOf(prefs.getBoolean("mirror", true))
    var countdown by mutableIntStateOf(prefs.getInt("countdown", 3))
    var kiosk by mutableStateOf(prefs.getBoolean("kiosk", false))

    fun save() {
        prefs.edit()
            .putBoolean("mirror", mirror)
            .putInt("countdown", countdown)
            .putBoolean("kiosk", kiosk)
            .apply()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var client: BoothClient
    private lateinit var local: LocalSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        local = LocalSettings(getSharedPreferences("booth_tablet", MODE_PRIVATE))
        client = BoothClient(this).also { it.start() }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                BoothScreen(client, local, onKiosk = ::setKiosk, onShare = ::shareTake)
            }
        }
        if (local.kiosk) setKiosk(true)
    }

    private fun setKiosk(on: Boolean) {
        runCatching { if (on) startLockTask() else stopLockTask() }
    }

    /** Scarica il video dal telefono e apre il menu Condividi (WhatsApp, email...). */
    private fun shareTake(takeFile: String, fileName: String, done: () -> Unit) {
        // il blocco kiosk impedisce di aprire altre app: lo togliamo
        runCatching { stopLockTask() }
        local.kiosk = false
        local.save()

        val dir = File(cacheDir, "share").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val dest = File(dir, fileName)
        client.download("/take/$takeFile", dest) { ok ->
            runOnUiThread {
                done()
                if (ok) {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "Condividi dedica"))
                } else {
                    Toast.makeText(this, "Impossibile preparare il video", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        client.stop()
        super.onDestroy()
    }
}
