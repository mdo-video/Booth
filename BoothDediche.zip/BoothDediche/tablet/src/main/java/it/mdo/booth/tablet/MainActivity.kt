package it.mdo.booth.tablet

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay

private const val MAX_SECONDS = 60
private const val MIRROR_PREVIEW = true   // effetto specchio solo sulla preview, il file non è specchiato

class MainActivity : ComponentActivity() {
    private lateinit var client: BoothClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        client = BoothClient(this).also { it.start() }
        setContent { BoothScreen(client) }
        runCatching { startLockTask() }   // screen pinning (kiosk)
    }

    override fun onDestroy() {
        client.stop()
        super.onDestroy()
    }
}

@Composable
fun BoothScreen(client: BoothClient) {
    val connected by client.connected.collectAsState()
    val frame by client.frame.collectAsState()
    val state by client.state.collectAsState()

    var starting by remember { mutableStateOf(false) }
    var countdown by remember { mutableIntStateOf(0) }
    var remaining by remember { mutableIntStateOf(MAX_SECONDS) }
    var savedBanner by remember { mutableStateOf(false) }
    val recording = state == "RECORDING"

    LaunchedEffect(starting) {
        if (starting) {
            for (i in 3 downTo 1) { countdown = i; delay(1000) }
            countdown = 0
            client.send("START")
            starting = false
        }
    }
    LaunchedEffect(recording) {
        if (recording) {
            remaining = MAX_SECONDS
            while (remaining > 0) { delay(1000); remaining-- }
        }
    }
    LaunchedEffect(state) {
        if (state.startsWith("SAVED")) { savedBanner = true; delay(3000); savedBanner = false }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        frame?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = if (MIRROR_PREVIEW) -1f else 1f },
                contentScale = ContentScale.Fit,
            )
        }
        if (!connected) {
            Text("Cerco il telefono…", color = Color.White, fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
        }
        if (countdown > 0) {
            Text("$countdown", color = Color.White, fontSize = 220.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
        }
        if (recording) {
            Text("${remaining}s", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
        }
        if (savedBanner) {
            Text("Dedica salvata ✓", color = Color(0xFF66BB6A), fontSize = 40.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
        }
        if (state.startsWith("ERROR")) {
            Text("Errore registrazione", color = Color.Red, fontSize = 28.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
        }

        Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp), contentAlignment = Alignment.Center) {
            if (recording) {
                CircularProgressIndicator(
                    progress = { remaining / MAX_SECONDS.toFloat() },
                    modifier = Modifier.size(200.dp),
                    color = Color(0xFFE53935),
                    strokeWidth = 8.dp,
                )
            }
            val enabled = connected && !starting
            Box(
                Modifier.size(160.dp).clip(CircleShape)
                    .background(if (enabled) Color(0xFFE53935) else Color.Gray)
                    .clickable(enabled = enabled) {
                        if (recording) client.send("STOP") else starting = true
                    },
                contentAlignment = Alignment.Center,
            ) {
                Text(if (recording) "STOP" else "REC", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
