package it.mdo.booth.tablet

import android.Manifest
import android.content.Intent
import android.hardware.input.InputManager
import android.content.pm.PackageManager
import android.os.Build
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File

/** Impostazioni che restano sul tablet. */
class LocalSettings(private val prefs: SharedPreferences) {
    var mirror by mutableStateOf(prefs.getBoolean("mirror", true))
    var countdown by mutableIntStateOf(prefs.getInt("countdown", 3))
    var kiosk by mutableStateOf(prefs.getBoolean("kiosk", false))
    var sound by mutableStateOf(prefs.getBoolean("sound", true))
    var autoQr by mutableStateOf(prefs.getBoolean("autoQr", true))
    /** codice di abbinamento mostrato sul telefono camera */
    var camKey by mutableStateOf(prefs.getString("camKey", "") ?: "")
    var wifiSsid by mutableStateOf(prefs.getString("wifiSsid", "") ?: "")
    var wifiPass by mutableStateOf(prefs.getString("wifiPass", "") ?: "")
    var welcome by mutableStateOf(prefs.getString("welcome", "Lascia una dedica!") ?: "")
    var frameDefaultDone by mutableStateOf(prefs.getBoolean("frameDefaultDone", false))
    /** telecomando Bluetooth associato (descrittore del dispositivo di input + nome da mostrare) */
    var remoteDevice by mutableStateOf(prefs.getString("remoteDevice", "") ?: "")
    var remoteName by mutableStateOf(prefs.getString("remoteName", "") ?: "")
    /** combinazioni di tasti del telecomando: "SINGLE=SHOOT,DOUBLE=MODE,..." (vuoto = predefinite) */
    var remoteMap by mutableStateOf(prefs.getString("remoteMap", "") ?: "")
    private fun parseRemoteMap(): Map<String, String> =
        remoteMap.split(",").mapNotNull { val p = it.split("="); if (p.size == 2) p[0] to p[1] else null }.toMap()
    fun remoteAction(gesture: String): String = parseRemoteMap()[gesture] ?: RemoteActions.defaults[gesture] ?: "NONE"
    fun setRemoteAction(gesture: String, action: String) {
        val m = RemoteActions.gestures.associate { it.name to remoteAction(it.name) }.toMutableMap()
        m[gesture] = action
        remoteMap = m.entries.joinToString(",") { "${it.key}=${it.value}" }
        save()
    }
    fun resetRemoteMap() { remoteMap = ""; save() }
    /** bordo attorno all'anteprima: 0 = pieno schermo, 1 = sottile, 2 = largo (i tasti stanno nel bordo) */
    var borderMode by mutableIntStateOf(prefs.getInt("borderMode", 2))
    /** colore del bordo, ARGB */
    var borderColor by mutableIntStateOf(prefs.getInt("borderColor", 0xFFD61F9E.toInt()))
    /** lingua dei testi per gli ospiti: "it" o "en" */
    var lang by mutableStateOf(prefs.getString("lang", "it") ?: "it")
    /** mostra agli ospiti la fila degli effetti */
    var filtersUi by mutableStateOf(prefs.getBoolean("filtersUi", true))
    /** effetti personalizzati (testo JSON), mandati anche al telefono */
    var customFilters by mutableStateOf(prefs.getString("customFilters", "") ?: "")
    /** effetti mostrati agli ospiti, scelti dalle impostazioni (vuoto = scelta consigliata) */
    var shownFx by mutableStateOf(prefs.getString("shownFx", "") ?: "")

    /** dediche nascoste dalla pellicola (restano sul telefono camera) */
    var hidden by mutableStateOf(prefs.getStringSet("hidden", emptySet())?.toSet() ?: emptySet())
    /** dopo quanti secondi di inattività ricompare la splash (0 = mai, solo all'apertura) */
    var splashIdleSec by mutableIntStateOf(prefs.getInt("splashIdleSec", 0))

    init { Lang.en = lang == "en"; Filters.setCustom(customFilters); Filters.setShown(shownFx) }

    fun save() {
        Lang.en = lang == "en"
        prefs.edit()
            .putBoolean("mirror", mirror)
            .putInt("countdown", countdown)
            .putBoolean("kiosk", kiosk)
            .putBoolean("sound", sound)
            .putBoolean("autoQr", autoQr)
            .putString("camKey", camKey)
            .putString("wifiSsid", wifiSsid)
            .putString("wifiPass", wifiPass)
            .putString("welcome", welcome)
            .putBoolean("frameDefaultDone", frameDefaultDone)
            .putString("remoteDevice", remoteDevice)
            .putString("remoteName", remoteName)
            .putString("remoteMap", remoteMap)
            .putString("lang", lang)
            .putBoolean("filtersUi", filtersUi)
            .putString("customFilters", customFilters)
            .putString("shownFx", shownFx)
            .putStringSet("hidden", hidden)
            .putInt("splashIdleSec", splashIdleSec)
            .putInt("borderMode", borderMode)
            .putInt("borderColor", borderColor)
            .apply()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var client: BoothClient
    private lateinit var local: LocalSettings
    private lateinit var frames: FrameStore
    private lateinit var dashCfg: DashConfig

    private val pickFrame = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            Thread {
                val ok = frames.importUri(uri)
                runOnUiThread {
                    if (ok) frames.enableOnSync = true
                    else Toast.makeText(this, "Immagine non valida", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    private val pickSplash = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            Thread {
                val ok = SplashStore.importUri(this, uri)
                runOnUiThread {
                    if (ok) SplashStore.show(false)
                    else Toast.makeText(this, "Immagine non valida", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    /** tiene aggiornata l'icona del telecomando (collegato / non collegato) */
    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) { RemoteState.refresh(local) }
        override fun onInputDeviceRemoved(deviceId: Int) { RemoteState.refresh(local) }
        override fun onInputDeviceChanged(deviceId: Int) { RemoteState.refresh(local) }
    }

    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startDash() }

    private fun startDash() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) DashcamService.start(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventLog.init(this)
        dashCfg = DashConfig(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        local = LocalSettings(getSharedPreferences("booth_tablet", MODE_PRIVATE))
        getSystemService(InputManager::class.java)?.registerInputDeviceListener(inputListener, null)
        RemoteState.refresh(local)
        SplashStore.load(this)
        SplashStore.pick = { chooseSplash() }
        frames = FrameStore(this).also { it.load() }
        if (frames.bitmap == null && !local.frameDefaultDone) {
            // prima apertura: cornice "Gaia +30" già pronta e attiva
            local.frameDefaultDone = true
            local.save()
            if (frames.importAsset("frame_gaia30.png")) frames.enableOnSync = true
        }
        client = BoothClient(this).also { it.key = local.camKey; it.start() }
        DashState.local = local
        DashState.frames = frames
        DashState.client = client
        DashState.kioskHook = { on -> runOnUiThread { setKiosk(on) } }
        DashState.updates = UpdateManager(this, "booth-tablet.apk", BuildConfig.UPDATE_TOKEN) {
            // il kiosk impedisce di aprire l'installazione: si toglie prima
            local.kiosk = false
            local.save()
            runOnUiThread { runCatching { stopLockTask() } }
        }.also { it.check(); it.startAutoCheck() }
        DashState.updates?.handleIntent(intent)
        window.decorView.post { DashState.updates?.let { Changelog.showIfNew(this, it.installedCode()) } }
        val need = buildList {
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) startDash() else askPerms.launch(need.toTypedArray())
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                androidx.compose.material3.ProvideTextStyle(androidx.compose.ui.text.TextStyle(fontFamily = Poppins)) {
                BoothScreen(client, local, frames, onKiosk = ::setKiosk, onPickFrame = ::chooseFrame, dashCfg = dashCfg)
                }
            }
        }
        if (local.kiosk) setKiosk(true)
    }

    /** Apre la galleria per scegliere la cornice (il kiosk blocca le altre app: si disattiva). */
    private fun chooseFrame() {
        runCatching { stopLockTask() }
        local.kiosk = false
        local.save()
        pickFrame.launch("image/*")
    }

    /** Apre la galleria per scegliere la splash (il kiosk blocca le altre app: si disattiva). */
    private fun chooseSplash() {
        runCatching { stopLockTask() }
        local.kiosk = false
        local.save()
        pickSplash.launch("image/*")
    }

    private fun setKiosk(on: Boolean) {
        runCatching { if (on) startLockTask() else stopLockTask() }
    }

    /** Telecomando Bluetooth: i suoi tasti diventano gesti (singola/doppia/tripla/lunga). */
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        DashState.updates?.handleIntent(intent)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        SplashStore.touch()
        if (::local.isInitialized && RemoteInput.handle(event, local)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        SplashStore.touch()
    }

    override fun onDestroy() {
        getSystemService(InputManager::class.java)?.unregisterInputDeviceListener(inputListener)
        DashState.kioskHook = null
        client.stop()
        super.onDestroy()
    }
}
