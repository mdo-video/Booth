package it.mdo.booth.control

/** Effetti colore disponibili (stesso id usato dal telefono camera e dal tablet). */
object Filters {
    val all = listOf(
        "none" to "Normale", "bn" to "B&N", "sepia" to "Seppia", "vintage" to "Vintage",
        "warm" to "Caldo", "cool" to "Freddo", "vivid" to "Vivido",
        "cinema" to "Cinema", "golden" to "Dorato", "romantic" to "Romantico", "pastel" to "Pastello", "noir" to "Noir",
        "faded" to "Sbiadito", "alien" to "Alieno", "matrix" to "Matrix", "pop" to "Rosa Pop", "fire" to "Fuoco",
    )
}
